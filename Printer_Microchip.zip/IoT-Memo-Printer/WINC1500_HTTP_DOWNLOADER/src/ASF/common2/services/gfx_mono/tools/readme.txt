
dump_display_over_serial.py
	Convert display data on a serial line to a .XPM file

bitmap.py
	Convert an indexed 2 color bitmap to an uint8_t array
